# העברה: איך נבנו פרומו "בית המקדש" ו"אש תמיד"

> **לשיחה המקבילה (Claude):** זה סיכום מלא של שיטת העבודה שבה נבנו הסרטונים mikdash-promo-v3.mp4 ו-mikdash-promo-epic.mp4 ("אש תמיד", 58 ש׳). הסקריפטים בתיקייה `scripts/` עובדים כמו שהם. הם מצפים לתיקיית עבודה `/home/claude/promo/` עם תתי-תיקיות `src/`, `full/`, `seg/`, `out/`, `fonts/`, `chk/`, אז אפשר להעתיק לשם או לשנות את הקבועים `P/F/S` בראש כל סקריפט. ענה למשתמש בעברית בלבד.

## 1. התמונה הכללית

```
Google Flow (תמונות מפתח ← קליפים של Veo)   Gemini (מוזיקה)
          │ הורדה עם שם ידוע                     │ הורדה עם שם ידוע
          ▼                                      ▼
  C:\Users\yaron\Downloads  ──stage──►  הקונטיינר: src/
          │
   prep.sh / slowmo.sh  →  full/   (מאסטרים 1080p, וגם 72/48fps להילוך איטי)
   analyze_beats.py     →  רשת ביטים של המוזיקה
   assemble_*.py + edit.py + titles.py  →  out/*.mp4  (חיתוך על הביט + כותרות + מוזיקה)
          │
   קידוד 2-pass לשיתוף (~25MB)  →  SendUserFile  →  device_commit_files אל C:\Users\yaron\Videos\mikdash-promo
```

## 2. וידאו: Google Flow ‏(flow.google.com)

- **פרויקט:** https://flow.google.com/project/cfbd5c3b-7488-4342-adab-a8a617749b0e ("…Jewish Priest Narrative"). עובדים דרך **הסוכן** בפאנל הצ'אט השמאלי.
- **קרדיטים:** Veo 3.1 Lite עולה 10 קרדיטים לקליפ של 8 ש׳ ב-720p. יש 50 קרדיטים חינם ביום, כלומר 5 קליפים. **שעת החידוש מופיעה בתפריט החשבון** (אווטאר למעלה משמאל: "הקרדיטים מתחדשים מדי יום בשעה …"), ובפעם האחרונה היא הייתה 15:12. לא לנחש את השעה, אלא לבדוק בתפריט.
- **תמונות** (Nano Banana) הן חינם. לכן קודם מייצרים תמונות מפתח לכל שוט ("IMAGES ONLY… do not spend credits"), ורק אחר כך מבקשים וידאו שמתחיל מהתמונה (start frame).
- **בקשת וידאו:** כותבים לסוכן הודעה אחת עם כל הקליפים. לכל קליפ מציינים "VIDEO n, start frame = <תיאור התמונה הקיימת>", ואת התנועה: מצלמה, דמויות ואש. הסוכן מציג כרטיס "להתחיל… תמורת X נקודות?" עם הכפתורים אישור, אישור לתמיד ודחייה. המשתמש אישר מראש להוציא את קרדיטי החינם היומיים.
- **הדמות:** כהן **בוגר כבן 20**. מדיניות Flow חוסמת תקריבים של דמות שנראית צעירה.
- **כללי דיוק שנאכפו בכל פרומפט:** "no stairs to the altar (smooth ramp only), no flags, no minarets, no on-screen text". בגדי כהונה: כתונת, מכנסיים, מגבעת כרוכה, אבנט, והכהן יחף. לא כותבים את השם המפורש בשום מקום.
- **חובה לבדוק כל קליפ פריים-פריים** (גיליונות מגע ב-ffmpeg: `fps=2,scale=320:-1,tile=8x2`). Veo מכניס אנכרוניזמים גם כשהפרומפט אוסר אותם. מה שנמצא:
  - קליפ הלילה: צריחי מסגד וכיפה בחלון הרקע. התיקון היה קרופ `crop=810:456:400:10` שמוציא את קו הרקיע (ראה `prep` בסעיף 5).
  - קליפ הריצה: **צלב** על גמלון ההיכל אחרי בערך 4 ש׳. התיקון היה להשתמש רק ב-0–3.75 ש׳.
  - קליפים ישנים: מדרגות למזבח ודגל מופיעים אחרי 3–4 ש׳. התיקון היה לחתוך לפני כן.

### הורדה מ-Flow עם שם קובץ ידוע (Claude in Chrome)
בלשונית של Flow, לפני ההורדות:
```js
window.__dl = window.__dl || [];
if (!window.__patched) { const orig = HTMLAnchorElement.prototype.click;
  HTMLAnchorElement.prototype.click = function(){ window.__dl.push({name:this.download, t:Date.now()}); return orig.apply(this, arguments); };
  window.__patched = true; }
```
אחר כך, בתצוגת "סרטונים": מרחפים על אריח, לוחצים ⋮, בוחרים **הורדה**, ואז **720p (גודל מקורי)**. האפשרויות 1080p ו-4K דורשות שדרוג. בסוף מריצים `JSON.stringify(window.__dl.map(d=>d.name))` ומעבירים את השמות ל-`device_stage_files` בנתיב `C:\Users\yaron\Downloads\<שם>`. בפעם הראשונה צריך לאשר ב-Chrome "הורדות מרובות" לאתר flow.google.com.
> אל תחפש קבצים עם `device_list_dir` על Downloads: הרשימה נקטעת ב-2000 פריטים.

## 3. מוזיקה: Gemini ‏(gemini.google.com)

- **יצירה:** בתפריט "העלאה וכלים" (+) בוחרים **יצירת מוזיקה**, ואז אורך "רגיל" ו"אינסטרומנטלי". הפרומפט מתאר מבנה בזמנים, למשל: שקט 0–8, בנייה, drop גדול, שיא עם מכות, דעיכה.
- **הורדה בלי חלון שמירה:** כפתור ה-MP3 פותח חלון "שמירה בשם" שתוקע את Chrome. במקום זה, בלשונית של Gemini:
```js
const el=[...document.querySelectorAll('audio,video,source')][0];
const b=await (await fetch(el.currentSrc||el.src,{credentials:'include'})).blob();   // video/mp4, הטראק + תמונת כריכה
const a=document.createElement('a'); a.href=URL.createObjectURL(b); a.download='mikdash_track_YYYYMMDD.mp4'; document.body.appendChild(a); a.click(); a.remove();
```
  אחר כך מריצים stage על הקובץ מ-Downloads, ומחלצים את האודיו: `ffmpeg -i x.mp4 -vn -c:a copy music.m4a`.
- **המוזיקה לא בהכרח מתנהגת כמו התיאור של Gemini.** חייבים למדוד אותה: `python3 scripts/analyze_beats.py music.m4a`. בטראק של "אש תמיד", Gemini אמר שה-drop ב-0:20, ובפועל הוא היה ב-24.08. הקצב הוא 120 BPM עם מקצב 3-3-2, ו-librosa טעה וזיהה 80. רשת הביטים: `G(k)=0.08+0.5k`, תיבה כל 2 ש׳.

## 4. עריכה בקונטיינר

| סקריפט | תפקיד |
|---|---|
| `prep.sh in out` | ‏720p → 1080p ‏(lanczos + unsharp + eq), ‏24fps מקורי |
| `slowmo.sh in ss dur out [fps]` | מאסטר באינטרפולציית תנועה (minterpolate mci) ב-72 או 48fps, כדי שהילוך איטי יהיה חלק ולא "יגמגם" |
| `analyze_beats.py` | אנרגיה לכל שנייה, מכות חזקות, ורשת ביטים קבועה |
| `edit.py` → `build(cuts, titles, small, music, out, fps=…)` | מניח קליפים על ציר הזמן לפי משכים מדויקים, עם הבזק לבן או שחור בכל חיתוך, `pre` (למשל crop), `vf`, `speed`, `fit`, `fade_out`, ו-`'black'` לרגע שקט. מוסיף שכבת כותרות אחת ואת המוזיקה |
| `titles.py spec.json out.mov` | כותרות עבריות קינטיות (Pillow + libraqm, ‏RTL): "פאנץ'" בכניסה, זהב או לבן, הבהוב "shine", ו-pulse על הביט. פונטים: Suez One לכותרות, Rubik לטקסט קטן |
| `assemble_epic.py` | **התבנית הכי טובה להעתקה:** ציר זמן מוגדר בתיבות (`BAR(n)`) ובביטים (`G(k)`), וכותרות בזמנים מוחלטים. הדגל `--draft` מציב חומרים זמניים עד שהקליפים החדשים מגיעים |
| `assemble_v3.py` | עריכה על רשת ביטים שמורה (`beats.npy`) מהטראק הקודם |

**שיעורים שנלמדו:**
- **אין שוטים קפואים.** המשתמש פסל פרלקסה 2.5D על תמונות סטילס ("לא טוב"). רק וידאו עם תנועה אמיתית.
- **ניקוד:** Suez One לא ממקם ניקוד כראוי. לכן כותבים פסוקים בלי ניקוד.
- **חיתוכים מהירים** (פחות מתיבה): הבזק קצר מאוד (`flash_d` 0.05) או בלי הבזק.
- **ה-drop:** מצמידים את הפיצוץ לביט עצמו, ולפניו שחור קצר בזמן השקט שבמוזיקה.
- **פלט:** ‏crf 17 למאסטר. לשיתוף משתמשים ב-2-pass: ‏3.5 Mbps ל-58 ש׳ או 6 Mbps ל-30 ש׳, ו-aac 160k. זה נותן פחות מ-30MB, שהוא המגבלה של `device_commit_files`.

## 5. הקרופ ללילה (דוגמה)
```
ffmpeg -i src/n_night.mp4 -an -vf "crop=810:456:400:10,scale=1920:1080:flags=lanczos,unsharp=5:5:0.8:5:5:0.0,eq=contrast=1.06:saturation=1.12" -c:v libx264 -crf 14 -preset slow -pix_fmt yuv420p full/f_night.mp4
```

## 6. מסירה למשתמש
1. `SendUserFile` עם קבצי השיתוף, ושומרים את ה-`file_uuid`.
2. `device_commit_files` עם ה-`fileUuid` אל `C:\Users\yaron\Videos\mikdash-promo\…`. ‏stagedPath מ-outputs נכשל עם 400.
3. המחשב: ‏YARON-BO-PC. ה-Chrome וגשר הקבצים נמצאים על אותו מחשב. התיקיות המחוברות הן Downloads ו-Videos.

## 7. "אש תמיד": מבנה (לדוגמה)
ראה `storyboard_v_epic.md`. בקצרה:
- פתיחה איטית על האש עם ויקרא ו, ו
- "כל לילה…" על הלפיד, ו"…וכל בוקר" על הצלילה מהחלל
- ריצה, חטיבה, כבש, ואז הרמת הבול בהילוך איטי
- שחור
- DROP: פיצוץ, עם "הדלק!"
- לויים, עם "השיר מתחיל"
- "עכשיו — זה אתה."
- מונטאז' שיא
- עגורן מעל המזבח (עם קרנות) אל ההיכל, עם "בית המקדש · המשחק · שחקו עכשיו!" ו-yaronbo-cmd.github.io/mikdash
- בכל הסרטון מופיעה ההערה "הסרטון מומחש — אינו צילום מתוך המשחק"
