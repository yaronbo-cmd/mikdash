"""Map a music track before cutting: tempo, beat grid phase, energy per second, strong hits.

usage: python3 analyze_beats.py track.(mp3|m4a|mp4|wav) [beats_out.npy]
Prints the energy curve so the intro / build / silence-before-drop / drop / climax are visible,
then fits a fixed-tempo grid (cuts land on 'phase + k * beat').
"""
import subprocess, sys, tempfile, os
import numpy as np, librosa

src = sys.argv[1]
wav = os.path.join(tempfile.mkdtemp(), 'a.wav')
subprocess.run(['ffmpeg', '-v', 'error', '-y', '-i', src, '-ac', '1', '-ar', '22050', wav], check=True)
y, sr = librosa.load(wav, sr=22050, mono=True)
print('duration', round(len(y) / sr, 2))
tempo, beats = librosa.beat.beat_track(y=y, sr=sr, units='time')
print('librosa tempo', tempo, '(check it: 80 vs 120 BPM confusions happen with 3-3-2 rhythms)')
if len(sys.argv) > 2:
    np.save(sys.argv[2], beats)
rms = librosa.feature.rms(y=y, hop_length=512)[0]
t = librosa.frames_to_time(np.arange(len(rms)), sr=sr, hop_length=512)
for s in np.arange(0, len(y) / sr, 1.0):
    m = (t >= s) & (t < s + 1)
    db = 20 * np.log10(rms[m].mean() + 1e-9)
    print(f'{s:5.0f}s {db:6.1f} dB ' + '#' * int(max(0, db + 50)))
on = librosa.onset.onset_strength(y=y, sr=sr, hop_length=256)
ot = librosa.times_like(on, sr=sr, hop_length=256)
pk = librosa.util.peak_pick(on, pre_max=20, post_max=20, pre_avg=40, post_avg=40, delta=on.std() * 2.5, wait=20)
print('strong hits', [round(float(ot[p]), 2) for p in pk])
bpm = float(input('BPM to grid on (e.g. 120): ') or 120) if sys.stdin.isatty() else 120.0
beat = 60 / bpm
best = max(((on[np.searchsorted(ot, np.arange(ph, ot[-1], beat))[:-1]].sum(), ph) for ph in np.arange(0, beat, 0.005)))
print(f'grid: beat {beat:.3f}s, phase {best[1]:.3f}s  ->  G(k) = {best[1]:.3f} + {beat:.3f}*k')
