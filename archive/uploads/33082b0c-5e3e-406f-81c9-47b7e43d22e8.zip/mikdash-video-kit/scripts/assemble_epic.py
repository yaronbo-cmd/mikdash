"""'אש תמיד' — the epic promo, cut on the new track's 120 BPM grid (bar = 2 s, downbeats at 0.08 + 2n).

usage: python3 assemble_epic.py out.mp4 [--draft]
--draft stands in existing clips for the new Flow clips that are not in yet.

Track map (measured): intro 0–8 · build 8–23.25 · silence 23.25–24.08 · DROP 24.08 · break 38.25–39.08 ·
climax 39.08–56.25 · ring-out to ~58.8
Sources: full/*.mp4 are 24 fps 1080p masters (prep.sh); full/sm_*.mp4 are motion-interpolated high-fps masters
(slowmo.sh) so speeds below 1 still give a new frame every 1/24 s.
"""
import os, sys
from edit import build, dur

P = '/home/claude/promo/'
F, S = P + 'full/', P + 'seg/'
draft = '--draft' in sys.argv


def src(name, placeholder):
    f = F + name
    if os.path.exists(f):
        return f
    if not draft:
        sys.exit(f'missing {f}')
    return placeholder


NIGHT = src('f_night.mp4', S + 's_night.mp4')         # cropped to keep the anachronistic skyline out of frame
RUN = src('sm_run.mp4', F + 'c4_ramp.mp4')           # 72 fps master of 0–3.75 s only (a cross appears on the pediment after ~4 s)
THROW = src('sm_throw.mp4', F + 'sm_c6_burst.mp4')   # 72 fps master of 0–4 s: the lift, then the explosion at ~2 s
THROW_RT = src('f_throw.mp4', F + 'c6_fire.mp4')     # real-time 24 fps
LEV = src('f_levites.mp4', S + 's_levites.mp4')
CRANE = src('sm_crane.mp4', S + 's_endbg.mp4')       # 48 fps master
OPEN, BURST = F + 'sm_c6_open.mp4', F + 'sm_c6_burst.mp4'   # 72 fps masters of c6 0–2.2 and 1.8–3.8
SPACE, CHOP, RAMP, ORBIT = F + 'c1_space.mp4', F + 'c3_chop.mp4', F + 'c4_ramp.mp4', F + 'c5_orbit.mp4'

G = lambda k: 0.08 + 0.5 * k          # beat k
BAR = lambda n: 0.08 + 2.0 * n        # downbeat of bar n
END = 58.6

# in-clip offsets / speeds for the new clips (set after viewing them)
NIGHT_SS, NIGHT2_SS = 0.3, 4.5
LEV_SS, LEV2_SS = 0.5, 4.5            # LEV_SS puts the cymbal flash (1.5 s) on beat 58
RUN_SS, RUN_SPEED, RUN2_SS, RUN3_SS = 0.0, 0.9, 1.6, 2.6
THROW_SS, THROW_SPEED = 0.0, 0.6      # the lift, slowed, ending just before the blast
BLAST_SS = 1.95                       # the blast, in sm_throw time
CRANE_SS, CRANE_SPEED = 0.0, 0.7

FIRE_CROP = 'crop=iw*0.42:ih*0.42:iw*0.02:ih*0.46'
BURST_ZOOM = 'crop=iw*0.72:ih*0.72:iw*0.12:ih*0.06'
DARK = 'eq=brightness=-0.05:contrast=1.12:saturation=1.2,vignette=PI/4'

# (start, end, source, ss, speed, extras)
timeline = [
    (0.0, BAR(2), OPEN, 0.0, 0.42, {'pre': FIRE_CROP, 'vf': DARK, 'flash': 'black', 'flash_d': 1.0}),
    (BAR(2), BAR(4), NIGHT, NIGHT_SS, 1.0, {'flash': 'black', 'flash_d': 0.3}),
    (BAR(4), BAR(6), SPACE, 0.0, 1.0, {'fit': True, 'span': 8.0}),
    (BAR(6), BAR(8), RUN, RUN_SS, RUN_SPEED, {}),
    (BAR(8), BAR(9), CHOP, 0.0, 1.0, {}),
    (BAR(9), BAR(10), RAMP, 0.1, 1.0, {}),
    (BAR(10), 23.33, THROW, THROW_SS, THROW_SPEED, {'fade_out': 0.35}),
    (23.33, BAR(12), 'black', 0, 1.0, {'flash': None}),
    # DROP — the same blast lands on the downbeat
    (BAR(12), BAR(13), THROW, BLAST_SS, 0.6, {'flash_d': 0.18}),
    (BAR(13), BAR(14), BURST, 0.6, 0.5, {'pre': BURST_ZOOM}),
    (BAR(14), BAR(16), LEV, LEV_SS, 1.0, {}),
    (BAR(16), BAR(18), ORBIT, 0.0, 0.9, {}),
    (BAR(18), G(73), CHOP, 0.8, 1.0, {}),
    (G(73), G(74), RAMP, 1.0, 1.0, {'flash_d': 0.05}),
    (G(74), G(75), BURST, 0.3, 1.0, {'pre': BURST_ZOOM, 'flash_d': 0.05}),
    (G(75), 38.25, RUN, RUN2_SS, 1.0, {'flash_d': 0.05}),
    (38.25, G(78), 'black', 0, 1.0, {'flash': None}),
    # CLIMAX
    (G(78), BAR(20), THROW_RT, 2.0, 1.0, {'flash_d': 0.2}),
    (BAR(20), BAR(21), LEV, LEV2_SS, 1.0, {}),
    (BAR(21), G(86), RUN, RUN3_SS, 1.0, {}),
    (G(86), BAR(22), CHOP, 4.6, 1.0, {'flash_d': 0.06}),
    (BAR(22), G(90), NIGHT, NIGHT2_SS, 1.0, {}),
    (G(90), BAR(23), BURST, 0.2, 1.0, {'flash_d': 0.06}),
    (BAR(23), BAR(24), ORBIT, 1.6, 1.0, {}),
    (BAR(24), END, CRANE, CRANE_SS, CRANE_SPEED, {'vf': 'eq=brightness=-0.04:saturation=1.08,vignette=PI/4.5', 'flash_d': 0.25}),
]
cuts = [dict(src=s, ss=ss, speed=sp, dur=round(b - a, 4), **ex) for a, b, s, ss, sp, ex in timeline]
for c in cuts:                       # draft stand-ins are shorter than the real clips
    if c['src'] != 'black' and c['ss'] > dur(c['src']) - 0.5:
        c['ss'] = 0.0


def T(t, until, text, size, y, style='white', **k):
    return dict(t=round(t, 3), d=round(until - t, 3), text=text, size=size, y=y, style=style, **k)


titles = [
    T(1.09, 3.98, 'אש תמיד תוקד על המזבח', 104, 0.40, 'gold'),
    T(2.10, 3.98, 'לא תכבה', 175, 0.585, 'gold', shine=[0.5]),
    T(4.45, 7.98, 'כל לילה…', 135, 0.83),
    T(9.90, 11.98, '…וכל בוקר', 135, 0.83),
    T(12.40, 15.98, 'מישהו היה צריך', 105, 0.73),
    T(12.95, 15.98, 'לשמור על האש.', 150, 0.855, 'gold'),
    T(24.12, 27.98, 'הדלק!', 270, 0.30, 'gold', shine=[0.5, 2.2], pulse=0.5, pulse_t0=0.08),
    T(28.30, 31.98, 'השיר מתחיל', 150, 0.83),
    T(32.30, 35.98, 'עכשיו —', 120, 0.70),
    T(32.80, 35.98, 'זה אתה.', 200, 0.845, 'gold', shine=[0.6]),
    T(46.15, 47.98, 'אש תמיד.', 210, 0.80, 'gold', shine=[0.3]),
    T(G(98), END - 0.05, 'בית המקדש', 210, 0.35, 'gold', shine=[0.5, 3.5]),
    T(G(102), END - 0.05, 'המשחק', 125, 0.555),
    T(BAR(26), END - 0.05, 'שחקו עכשיו!', 108, 0.725, 'gold', pulse=0.5, pulse_t0=0.08),
]
small = [
    {'t': 0.4, 'd': 3.5, 'text': 'הסרטון מומחש — אינו צילום מתוך המשחק', 'size': 24, 'y': 0.955},
    {'t': 2.6, 'd': 1.38, 'text': 'ויקרא ו, ו', 'size': 38, 'y': 0.765},
    {'t': 52.6, 'd': END - 52.65, 'text': 'yaronbo-cmd.github.io/mikdash', 'size': 46, 'y': 0.855},
    {'t': 52.6, 'd': END - 52.65, 'text': 'הסרטון מומחש — אינו צילום מתוך המשחק', 'size': 24, 'y': 0.955},
]
build(cuts, titles, small, P + 'src/music_epic.m4a', sys.argv[1], tag='epic', fps=24, vfade=0.8, afade=0.9)
