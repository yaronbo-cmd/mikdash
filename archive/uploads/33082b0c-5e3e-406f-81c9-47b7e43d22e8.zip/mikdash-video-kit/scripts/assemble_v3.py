"""Promo v3: the v2 cut on the same beat grid, with the three frozen shots replaced by real generated motion.

usage: python3 assemble_v3.py out.mp4
needs full/f_levites.mp4, f_night.mp4, f_run.mp4, f_throw.mp4, f_crane.mp4 (1080p masters of the new Flow clips)
"""
import sys
import numpy as np
from edit import build

S, F = '/home/claude/promo/seg/', '/home/claude/promo/full/'
B = np.load(S + 'beats.npy')
beat = float(np.median(np.diff(B)))
END_LEN = 5.2
LEV_SS, NIGHT_SS, RUN_SS, BLAST_SS, CRANE_SS = 0.6, 0.5, 0.4, 1.9, 2.6   # where the action is in each new clip

plan = [  # (source, ss, speed, from beat, to beat, extra)
    (S + 'v1_space.mp4', 0, 1, None, 0, {'fit': True}),
    (S + 'v3_chop.mp4', 0, 1, 0, 4, {}),
    (S + 'v4_ramp.mp4', 0, 1, 4, 8, {}),
    (S + 'v6_fire.mp4', 0, 1, 8, 16, {}),
    (F + 'f_levites.mp4', LEV_SS, 1, 16, 22, {}),
    (F + 'f_night.mp4', NIGHT_SS, 1, 22, 28, {}),
    (S + 'v5_orbit.mp4', 0, 1, 28, 32, {}),
    (F + 'f_run.mp4', RUN_SS, 1, 32, 36, {}),
    (F + 'f_throw.mp4', BLAST_SS, 1, 36, 40, {}),
    (F + 'f_crane.mp4', CRANE_SS, 1, 40, 'end', {'vf': 'eq=brightness=-0.08:saturation=1.08,vignette=PI/4'}),
]
cuts = []
for src, ss, sp, a, b, ex in plan:
    ta = 0.0 if a is None else float(B[a])
    tb = ta + END_LEN if b == 'end' else float(B[b])
    cuts.append(dict(src=src, ss=ss, speed=sp, dur=tb - ta, t0=ta, **ex))


def T(i, at, text, size, y, style, **k):
    t = cuts[i]['t0'] + at
    end = cuts[i]['t0'] + cuts[i]['dur']
    return dict(t=round(t, 3), d=round(end - t - 0.04, 3), text=text, size=size, y=y, style=style, **k)


total = sum(c['dur'] for c in cuts)
titles = [
    T(0, 4.7, 'בית המקדש', 210, 0.42, 'gold'),
    T(1, 0.2, 'בקע.', 220, 0.28, 'white'),
    T(2, 0.2, 'העלה.', 220, 0.28, 'white'),
    T(3, 0.6, 'הדלק!', 250, 0.28, 'gold'),
    T(4, 0.25, 'השיר מתחיל', 150, 0.82, 'white'),
    T(5, 0.25, 'השמירה בלילה', 150, 0.82, 'white'),
    T(6, 0.15, 'אתה הכהן.', 170, 0.80, 'gold'),
    T(9, 0.15, 'בית המקדש', 205, 0.35, 'gold', shine=[0.6, 2.6]),
    T(9, 0.65, 'המשחק', 125, 0.555, 'white'),
    T(9, 1.15, 'שחקו עכשיו!', 105, 0.725, 'gold', pulse=beat, pulse_t0=cuts[9]['t0']),
]
t9 = cuts[9]['t0']
small = [
    {'t': 0.3, 'd': 4.0, 'text': 'הסרטון מומחש — אינו צילום מתוך המשחק', 'size': 24, 'y': 0.955},
    {'t': round(t9 + 1.5, 3), 'd': round(total - t9 - 1.5, 3), 'text': 'yaronbo-cmd.github.io/mikdash', 'size': 46, 'y': 0.855},
    {'t': round(t9 + 1.5, 3), 'd': round(total - t9 - 1.5, 3), 'text': 'הסרטון מומחש — אינו צילום מתוך המשחק', 'size': 24, 'y': 0.955},
]
for c in cuts:
    c.pop('t0')
build(cuts, titles, small, '/home/claude/promo/src/music.mp3', sys.argv[1], tag='v3', fps=30)
