"""Shared cutter: lay clips on a music timeline, add flash cuts, one kinetic-titles overlay and the music.

build(cuts, titles, small, music, out)
  cuts:   [{'src': path, 'ss': start in source (s), 'speed': 1.0, 'dur': seconds on the timeline,
            'vf': extra ffmpeg filters (optional), 'flash': 'white'|'black'|None, 'fit': True}]
          'fit': retime the source span to fill 'dur' exactly (used for the space dive).
  titles / small: titles.py entries with absolute timeline times.
"""
import json, subprocess, sys

FPS = 30
TITLES = '/home/claude/promo/titles.py'


def dur(f):
    return float(subprocess.check_output(['ffprobe', '-v', 'error', '-show_entries', 'format=duration', '-of', 'csv=p=0', f]).decode())


def build(cuts, titles, small, music, out, music_ss=0.0, tag='x', vfade=0.7, afade=1.6, crf=17, fps=FPS):
    total = sum(c['dur'] for c in cuts)
    spec = f'/home/claude/promo/seg/titles_{tag}.json'
    tmov = f'/home/claude/promo/seg/t_{tag}.mov'
    json.dump({'fps': fps, 'w': 1920, 'h': 1080, 'dur': total, 'titles': titles, 'small': small},
              open(spec, 'w'), ensure_ascii=False)
    subprocess.run(['python3', TITLES, spec, tmov], check=True)
    inputs, fc, labels = [], [], []
    for i, c in enumerate(cuts):
        d = c['dur']
        sp = c.get('speed', 1.0)
        if c['src'] == 'black':                                   # a silent beat of darkness
            inputs += ['-f', 'lavfi', '-t', f'{d + 0.1:.3f}', '-i', f'color=c=black:s=1920x1080:r={fps}']
            avail = d + 0.1
        else:
            inputs += ['-ss', f"{c.get('ss', 0):.3f}", '-i', c['src']]
            avail = (dur(c['src']) - c.get('ss', 0)) / sp
        ch = f'[{i}:v]setpts=(PTS-STARTPTS)/{sp:.5f},'
        if c.get('fit'):
            span = c.get('span', dur(c['src']) - c.get('ss', 0))     # source seconds stretched/squeezed onto 'dur'
            ch = f"[{i}:v]setpts=(PTS-STARTPTS)*{d / span:.5f},"
        elif avail < d:
            ch += f'tpad=stop_mode=clone:stop_duration={d - avail + 0.2:.3f},'
        if c.get('pre'):                                         # e.g. a crop, before the frame is scaled back to 1080p
            ch += c['pre'] + ','
        ch += f'fps={fps},trim=duration={d:.4f},setpts=PTS-STARTPTS,scale=1920:1080:flags=lanczos,setsar=1'
        if c.get('vf'):
            ch += ',' + c['vf']
        ch += ',format=yuv420p'
        fl = c.get('flash', 'white' if i else None)
        if fl:
            ch += f',fade=t=in:st=0:d={c.get("flash_d", 0.10)}:color={fl}'
        if c.get('fade_out'):
            ch += f',fade=t=out:st={d - c["fade_out"]:.3f}:d={c["fade_out"]}:color={c.get("fade_color", "black")}'
        fc.append(ch + f'[p{i}]'); labels.append(f'[p{i}]')
    n = len(cuts)
    inputs += ['-i', tmov, '-ss', f'{music_ss:.3f}', '-i', music]
    fc.append(''.join(labels) + f'concat=n={n}:v=1:a=0[vc]')
    fc.append(f'[vc][{n}:v]overlay=format=auto,fade=t=out:st={total - vfade:.3f}:d={vfade},format=yuv420p[vo]')
    fc.append(f'[{n + 1}:a]atrim=duration={total:.3f},afade=t=out:st={total - afade:.3f}:d={afade},asetpts=PTS-STARTPTS[ao]')
    cmd = ['ffmpeg', '-v', 'error', '-y'] + inputs + ['-filter_complex', ';'.join(fc), '-map', '[vo]', '-map', '[ao]',
           '-c:v', 'libx264', '-crf', str(crf), '-preset', 'slow', '-profile:v', 'high', '-pix_fmt', 'yuv420p', '-r', str(fps),
           '-c:a', 'aac', '-b:a', '192k', '-movflags', '+faststart', out]
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode:
        print(r.stderr[-3000:]); sys.exit(1)
    print('done', out, round(total, 2))
    return total
