#!/bin/sh
# prep.sh in.mp4 out.mp4 — Flow 720p → 1080p master (lanczos + light sharpen + the promo's grade), native 24 fps kept
ffmpeg -v error -y -i "$1" -an -vf "scale=1920:1080:flags=lanczos,unsharp=5:5:0.7:5:5:0.0,eq=contrast=1.06:saturation=1.12" \
  -c:v libx264 -crf 14 -preset slow -pix_fmt yuv420p "$2"
