#!/bin/sh
# slowmo.sh in.mp4 ss dur out.mp4 [fps] — motion-interpolated high-fps 1080p master for clean slow motion (setpts later)
F=${5:-72}
ffmpeg -v error -y -ss "$2" -t "$3" -i "$1" -an -vf "minterpolate=fps=$F:mi_mode=mci:mc_mode=aobmc:me_mode=bidir:vsbmc=1,scale=1920:1080:flags=lanczos,unsharp=5:5:0.7:5:5:0.0,eq=contrast=1.06:saturation=1.12" \
  -c:v libx264 -crf 14 -preset medium -pix_fmt yuv420p "$4"
