"""Render the promo's Hebrew kinetic titles as one RGBA overlay video (qtrle .mov).

usage: python3 titles.py spec.json out.mov
spec: {"fps":30,"w":1920,"h":1080,"dur":36.0,
       "titles":[{"t":0.6,"d":1.8,"text":"בית המקדש","size":190,"y":0.42,"style":"gold"}, ...],
       "small":[{"t":30,"d":6,"text":"...","size":30,"y":0.95}]}
Pillow with libraqm lays out the Hebrew right-to-left.
"""
import json, subprocess, sys, math
from PIL import Image, ImageDraw, ImageFont, ImageFilter

FONT_DISPLAY = '/home/claude/promo/fonts/SuezOne-Regular.ttf'
FONT_BODY = '/home/claude/promo/fonts/Rubik[wght].ttf'


def text_layer(text, size, style, font_path=FONT_DISPLAY, weight=None):
    font = ImageFont.truetype(font_path, size, layout_engine=ImageFont.Layout.RAQM)
    if weight:
        try:
            font.set_variation_by_axes([weight])
        except Exception:
            pass
    pad = int(size * 0.6)
    bbox = font.getbbox(text, direction='rtl', language='he')
    w, h = bbox[2] - bbox[0] + 2 * pad, bbox[3] - bbox[1] + 2 * pad
    ox, oy = pad - bbox[0], pad - bbox[1]
    stroke = max(2, size // 22)
    # glow
    glow = Image.new('L', (w, h), 0)
    ImageDraw.Draw(glow).text((ox, oy), text, font=font, fill=255, direction='rtl', language='he', stroke_width=stroke * 3)
    glow = glow.filter(ImageFilter.GaussianBlur(size / 9))
    out = Image.new('RGBA', (w, h), (0, 0, 0, 0))
    gc = (255, 170, 40) if style == 'gold' else (255, 255, 255)
    out.paste(Image.new('RGBA', (w, h), gc + (0,)), (0, 0))
    out.putalpha(glow.point(lambda v: int(v * 0.55)))
    # dark outline + drop shadow
    sh = Image.new('L', (w, h), 0)
    ImageDraw.Draw(sh).text((ox + stroke, oy + stroke * 2), text, font=font, fill=255, direction='rtl', language='he', stroke_width=stroke)
    shadow = Image.new('RGBA', (w, h), (25, 14, 4, 0)); shadow.putalpha(sh.point(lambda v: int(v * 0.8)))
    out = Image.alpha_composite(out, shadow)
    # the letters: vertical gold gradient (or white) with a dark-brown stroke
    mask = Image.new('L', (w, h), 0)
    ImageDraw.Draw(mask).text((ox, oy), text, font=font, fill=255, direction='rtl', language='he')
    smask = Image.new('L', (w, h), 0)
    ImageDraw.Draw(smask).text((ox, oy), text, font=font, fill=255, direction='rtl', language='he', stroke_width=stroke)
    st = Image.new('RGBA', (w, h), (40, 22, 6, 0)); st.putalpha(smask)
    out = Image.alpha_composite(out, st)
    if style == 'gold':
        grad = Image.new('RGBA', (1, h))
        top, mid, bot = (255, 246, 196), (255, 205, 80), (196, 120, 20)
        for y in range(h):
            u = (y - oy) / max(1, (h - 2 * pad))
            u = min(1, max(0, u))
            c = [int(top[i] + (mid[i] - top[i]) * u * 2) if u < .5 else int(mid[i] + (bot[i] - mid[i]) * (u - .5) * 2) for i in range(3)]
            grad.putpixel((0, y), tuple(c) + (255,))
        fill = grad.resize((w, h))
    else:
        fill = Image.new('RGBA', (w, h), (255, 255, 255, 255))
    fill.putalpha(mask)
    out = Image.alpha_composite(out, fill)
    return out


def ease_out_back(x):
    c1, c3 = 1.70158, 2.70158
    return 1 + c3 * (x - 1) ** 3 + c1 * (x - 1) ** 2


def main(spec_path, out_path):
    S = json.load(open(spec_path))
    fps, W, H, dur = S['fps'], S['w'], S['h'], S['dur']
    layers = []
    for T in S.get('titles', []):
        layers.append((T, text_layer(T['text'], T['size'], T.get('style', 'gold'))))
    for T in S.get('small', []):
        layers.append((dict(T, small=True), text_layer(T['text'], T['size'], 'white', FONT_BODY, 500)))
    n = int(round(dur * fps))
    ff = subprocess.Popen(['ffmpeg', '-v', 'error', '-y', '-f', 'rawvideo', '-pix_fmt', 'rgba', '-s', f'{W}x{H}', '-r', str(fps), '-i', '-',
                           '-c:v', 'qtrle', out_path], stdin=subprocess.PIPE)
    blank = Image.new('RGBA', (W, H), (0, 0, 0, 0))
    for f in range(n):
        t = f / fps
        frame = blank.copy()
        for T, L in layers:
            a, d = T['t'], T['d']
            if not (a <= t < a + d):
                continue
            u = t - a
            if T.get('small'):
                k, alpha = 1.0, min(1, u / 0.4, (a + d - t) / 0.4)
            else:
                tin, tout = 0.28, 0.22
                if u < tin:
                    x = u / tin; k = 0.55 + 0.45 * ease_out_back(x); alpha = min(1, x * 1.6)
                elif t > a + d - tout:
                    x = (a + d - t) / tout; k = 1.0 + (1 - x) * 0.25; alpha = x
                else:
                    k = 1.0 + 0.04 * (u - tin) / max(0.01, d - tin - tout); alpha = 1  # slow push-in while it holds
                if T.get('pulse') and u >= tin:            # a bounce on every beat
                    ph = ((t - T.get('pulse_t0', 0)) % T['pulse']) / T['pulse']
                    k *= 1 + 0.07 * math.exp(-ph * 6)
            Lw, Lh = L.size
            src_l = L
            for sh_at in T.get('shine', []):               # a bright band sweeping across the letters
                v = (u - sh_at) / 0.7
                if 0 <= v <= 1:
                    import numpy as np
                    A = np.asarray(L, dtype=np.float32)
                    yy, xx = np.mgrid[0:Lh, 0:Lw].astype(np.float32)
                    pos = -0.3 * Lw + v * 1.6 * Lw
                    band = np.exp(-((xx - pos + 0.35 * yy) / (0.07 * Lw)) ** 2) * (A[..., 3] / 255.0) * 0.85
                    A[..., :3] = A[..., :3] + (255 - A[..., :3]) * band[..., None]
                    src_l = Image.fromarray(A.astype(np.uint8), 'RGBA')
            im = src_l.resize((max(1, int(Lw * k)), max(1, int(Lh * k))), Image.BICUBIC) if abs(k - 1) > 1e-3 else src_l
            if alpha < 1:
                im = im.copy(); im.putalpha(im.getchannel('A').point(lambda v: int(v * max(0, alpha))))
            x0 = (W - im.size[0]) // 2 + int(T.get('dx', 0) * W)
            y0 = int(T.get('y', 0.5) * H - im.size[1] / 2)
            frame.alpha_composite(im, (x0, y0))
        ff.stdin.write(frame.tobytes())
    ff.stdin.close(); ff.wait()


if __name__ == '__main__':
    main(sys.argv[1], sys.argv[2])
